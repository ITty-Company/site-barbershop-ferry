#!/usr/bin/env python3
"""Generates the static HTML pages of barbershop-ferry (Barbershop Ferry, Stationsstraat 130 Waalwijk).
Template: sites/kapsalon-haar/_notes/build.py (same site.js / style.css mechanics; site.js extended with a chunked film player).
Run:  python3 _notes/build.py   (writes *.html next to _notes/ and COPY.md)
Only verified facts: name, address, phone, the four Fresha services. No prices, hours, reviews, names or years."""
import json, html
from pathlib import Path
OUT = Path(__file__).resolve().parent.parent

TEL = 'tel:+31628718927'; TELT = '06 28 71 89 27'
WA = 'https://wa.me/31628718927'
ROUTE = 'https://www.google.com/maps/search/?api=1&amp;query=Stationsstraat+130+5141+GH+Waalwijk'
BOEK = 'afspraak.html'
ADR = 'Stationsstraat 130'; PC = '5141 GH Waalwijk'
HOURS_NOTE = 'Vaste tijden volgen.'

I = {
 'tel': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 4h3.5l1.6 4.2-2.2 1.4a11 11 0 0 0 6.5 6.5l1.4-2.2L20 15.5V19a1.5 1.5 0 0 1-1.6 1.5C10.6 20 4 13.4 3.5 5.6A1.5 1.5 0 0 1 5 4z"/></svg>',
 'pin': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" aria-hidden="true"><path d="M12 21s-7-6.2-7-11.5A7 7 0 0 1 19 9.5C19 14.8 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.5"/></svg>',
 'wa': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round" aria-hidden="true"><path d="M4 19.5l1.3-3.8A8 8 0 1 1 8.6 19z"/></svg>',
 'cal': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" aria-hidden="true"><rect x="3.5" y="5" width="17" height="15.5" rx="3"/><path d="M3.5 10h17M8 3v4M16 3v4"/></svg>',
 'cut': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" aria-hidden="true"><circle cx="6.5" cy="7" r="2.6"/><circle cx="6.5" cy="17" r="2.6"/><path d="M8.6 8.5 20 17M8.6 15.5 20 7"/></svg>',
 'clock': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/></svg>',
}

def btn(href, label, kind='', icon=None, ext=False):
    cls = 'btn' + (' ' + kind if kind else '')
    ic = I[icon] if icon else ''
    t = ' target="_blank" rel="noopener"' if ext else ''
    return f'<a class="{cls}" href="{href}"{t}>{ic}{label}</a>'

B_BOEK = lambda label='Plan je afspraak', kind='': btn(BOEK, label, kind, 'cal')
B_TEL = lambda kind='ghost': btn(TEL, f'Bel {TELT}', kind, 'tel')
B_ROUTE = lambda kind='ghost': btn(ROUTE, 'Route plannen', kind, 'pin', True)
B_WA = lambda kind='ghost': f'<span class="wa-wrap">{btn(WA, "WhatsApp", kind, "wa", True)}<span class="wa-note">nog te bevestigen</span></span>'

PRE = ("<script>document.documentElement.classList.add('js');try{var d=JSON.parse(sessionStorage.getItem('paal')||'null');"
       "if(d){sessionStorage.removeItem('paal');var c=document.documentElement.classList;c.add('pl-closed','pl-noanim');if(d.b)c.add('pl-back');"
       "window.__pl=d.l;setTimeout(function(){c.remove('pl-closed')},2200)}}catch(e){}</script>")

FAV = ("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Crect width='32' height='32' rx='9' fill='%2317233F'/%3E"
       "%3Crect x='11' y='4' width='10' height='24' rx='5' fill='%23F5F3EE'/%3E%3Cpath d='M11 9l10-4M11 15l10-4M11 21l10-4M11 27l10-4' stroke='%23C42032' stroke-width='2.4'/%3E%3C/svg%3E")

def head(title, desc, og='assets/img/k7.webp'):
    return f'''<!DOCTYPE html>
<html lang="nl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>{title}</title>
<meta name="description" content="{desc}">
<meta name="theme-color" content="#F5F3EE">
<meta property="og:title" content="{title}">
<meta property="og:description" content="{desc}">
<meta property="og:image" content="{og}">
<meta name="robots" content="noindex">
<link rel="icon" href="{FAV}">
{PRE}
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Big+Shoulders+Display:wght@600;700&amp;family=Atkinson+Hyperlegible+Next:wght@400;500&amp;family=Spline+Sans+Mono:wght@500&amp;display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<a class="skip" href="#inhoud">Naar inhoud</a>
'''

def header(cur):
    links = [('diensten.html', 'Diensten'), ('afspraak.html', 'Afspraak'), ('over-ons.html', 'Over ons'), ('contact.html', 'Contact')]
    nav = ''.join(f'<a href="{h}"' + (' aria-current="page"' if h == cur else '') + f'>{t}</a>' for h, t in links)
    return f'''<header class="hd">
  <a class="logo" href="index.html" aria-label="Barbershop Ferry — home"><span>Ferry<em>.</em></span><small>Barbershop · Waalwijk</small></a>
  <nav class="nav" id="menu" aria-label="Hoofdmenu">{nav}
    <div class="mnav">{B_BOEK('Afspraak maken')}{B_TEL()}{B_WA()}<p>{ADR}, Waalwijk</p></div>
  </nav>
  <a class="btn pill" href="afspraak.html">Afspraak maken</a>
  <button class="burger" type="button" aria-label="Menu" aria-expanded="false" aria-controls="menu"><span></span><span></span><span></span></button>
</header>
<main id="inhoud">
'''

def finale(frm='var(--foam)', still=None):
    if still:
        d, m, cap, cls = still
        bg = f'<div class="bg"><div class="kbw" data-kb><picture><source media="(max-width:760px)" srcset="{m}"><img src="{d}" alt="" loading="lazy"></picture></div></div>'
    else:
        cap, cls = 'Sfeerbeeld — niet de echte gevel', ''
        bg = '<div class="bg"><div class="kbw" data-kb><img src="assets/img/loop-contact-0.webp" alt="" loading="lazy"><video data-auto data-src="assets/loop-contact.mp4" poster="assets/img/loop-contact-0.webp" muted playsinline loop preload="none" aria-hidden="true"></video></div></div>'
    return f'''<section class="finale {cls}" style="--from:{frm}" aria-label="Tot zo">
  {bg}
  <canvas class="dust" data-k="warm" aria-hidden="true"></canvas>
  <span class="cap mono">{cap}</span>
  <div class="wrap"><div class="box glow-follow">
    <span class="eyebrow">{ADR} · Waalwijk</span>
    <h2 class="words">tot zo in de stoel.</h2>
    <p class="lead rv">Plan je afspraak online in een minuut, of bel even als je liever iemand spreekt. Je vindt Barbershop Ferry aan de Stationsstraat 130 in Waalwijk.</p>
    <div class="row rv" style="--d:1">{B_BOEK()}{B_TEL()}{B_ROUTE()}</div>
  </div></div>
</section>
'''

def footer(extra_js=''):
    return f'''</main>
<footer>
  <div class="wrap">
    <div><b>Barbershop Ferry</b>{ADR}, {PC}<a class="tel" href="{TEL}">{TELT}</a><a href="{WA}" target="_blank" rel="noopener">WhatsApp (nog te bevestigen)</a><a href="{ROUTE}" target="_blank" rel="noopener">Route plannen</a></div>
    <div><b>Openingstijden</b>Bel of boek online.<br><small>{HOURS_NOTE}</small></div>
    <div><b>Pagina's</b><a href="index.html">Home</a><a href="diensten.html">Diensten</a><a href="afspraak.html">Afspraak</a><a href="over-ons.html">Over ons</a><a href="contact.html">Contact</a></div>
    <p class="demo"><strong>Ontwerpvoorstel — ITty Company.</strong> Alle beelden zijn sfeerbeelden (AI), geen foto's van de zaak. Diensten volgens Fresha; prijzen op aanvraag.</p>
  </div>
</footer>
<div class="ctabar">{B_BOEK('Afspraak')}{btn(TEL, 'Bel', 'ghost', 'tel')}</div>
<div class="grain" aria-hidden="true"></div>
<div id="paal" aria-hidden="true"><div class="strips">{''.join(f'<i style="--k:{k}"></i>' for k in range(12))}</div><div class="lbl"></div></div>
<script src="assets/vendor/lenis.min.js"></script>
<script src="assets/site.js"></script>
{extra_js}</body>
</html>
'''

def fstills(items):
    lis = ''.join(f'<li><picture><source media="(max-width:760px)" srcset="{m}"><img src="{d}" alt="" loading="lazy"></picture><div class="box">{inner}</div><span class="cap mono">{cap}</span></li>' for d, m, inner, cap in items)
    return f'<ol class="fstills">{lis}</ol>'

HERO_LEAD = 'Knippen, baard trimmen en scheren aan de Stationsstraat in Waalwijk. Plan je afspraak online, of bel even.'

# ---------------------------------------------------------------- services (exactly the four on Fresha)
SVC = [
 ('knippen', 'Knippen', 'Haircut', 'Je haar weer in model: kort, een fade of gewoon netjes bijgewerkt.'),
 ('knippen-baard', 'Knippen &amp; baard trimmen', 'Haircut &amp; Beard Trim', 'Haar en baard in één keer, zodat alles weer bij elkaar past.'),
 ('baard', 'Baard trimmen', 'Beard Trim', 'Je baard op lengte en in vorm, met strakke lijnen.'),
 ('scheren', 'Baard scheren', 'Beard Shave', 'Glad geschoren, met warme handdoek en een scherp mes.'),
]
FRESHA = 'op Fresha vermeld · prijs op aanvraag'

# ======================================================================= INDEX
# film timeline (s), from _notes/seg.py: K1 0–2.2 · zoom –3.7 · K2 –5.3 · paal-banen –6.9 · K3 –8.7 · zoom –10.1 · K4 –11.7 · licht –13.2 · K6 –14.9 · damp –16.5 · K5 –18.1 · rimpel –19.7 · K7 –22.1
# chunk list + start times are written by _notes/assemble.sh into _notes/segs.json
SEGS = json.loads((OUT / '_notes' / 'segs.json').read_text()) if (OUT / '_notes' / 'segs.json').exists() else {'d': '0', 'm': '0', 'src': 'assets/film-main.mp4', 'srcm': 'assets/film-main-m.mp4'}
FILM_SRC, FILM_SRC_M = SEGS['src'], SEGS['srcm']
AT = SEGS.get('at', [1.2, 4.6, 7.8, 12.2, 15.3, 18.4, 21.5, 26.9])
CH = [
 dict(t='even naar Ferry.', s='Een gewone ochtend aan de Stationsstraat. De paal draait al.', fx='dust', cool=1, at=AT[0], pos='tc', cx=.3),
 dict(t='de paal draait.', s='Rood, wit, blauw: al eeuwen het teken van de barbier.', fx='glint', at=AT[1], pos='tl', g=[.30, .42, .44, .12], gm=[.08, .45, .40, .12], cx=.46),
 dict(t='binnen is het rustig.', s='Mint tegels, daglicht, een rode stoel.', fx='dust', at=AT[2], pos='tc', cx=.5),
 dict(t='van nul tot acht.', s='Opzetkam na opzetkam: zo ontstaat een fade.', fx='hair', at=AT[3], pos='tc', cx=.2, floorm=.9),
 dict(t='strak langs de lijn.', s='Het mes van de tondeuse, scherp in het ochtendlicht.', fx='dust', warm=1, at=AT[4], pos='tl', cx=.44),
 dict(t='warm voor het mes.', s='Een warme handdoek maakt de huid zacht voor het scheren.', fx='steam', at=AT[5], pos='tr', src=[.2, .46], srcm=[.33, .46], cx=.26),
 dict(t='een druppel voor de baard.', s='Olie maakt een baard zacht — en hij ruikt goed.', fx='glint', warm=1, at=AT[6], pos='tc', g=[.3, .73, .7, .73], gm=[.1, .73, .9, .73], cx=.5),
 dict(t='en dan: <em>jouw beurt.</em>', s='De stoel staat klaar. Kies een tijd die je uitkomt.', fx='dust', warm=1, at=AT[7], pos='tc', cx=.5),
]
CARDS = [
 ('Een barbier aan de Stationsstraat', 'Barbershop Ferry zit aan de Stationsstraat 130 in Waalwijk. Je herkent een barbier al van ver aan de paal naast de deur. Binnen draait het om één ding: dat je strak en verzorgd weer naar buiten loopt.', ''),
 ('Het oudste uithangbord', 'De rood-wit-blauwe paal hangt al eeuwen bij barbiers. Hij draait, zodat je hem ziet vanaf de overkant van de straat. Een beter teken bestaat eigenlijk niet: hier wordt geknipt en geschoren.', ''),
 ('Even zitten', 'Bij de barbier hoef je even niets. Jas uit, cape om, achterover in de stoel. Vertel wat je wilt — korter, een fade, alleen de baard — en de rest gebeurt vanzelf.', ''),
 ('De fade, stap voor stap', 'Een fade is een overgang: onderaan heel kort, naar boven toe steeds langer. Dat doe je met opzetkammen van klein naar groot, en met geduld. Elke stap moet vloeiend in de volgende overlopen — dan zie je geen lijn meer, alleen een verloop.', 'bl'),
 ('Lijnen die kloppen', 'Een goede knipbeurt valt op aan de details: de nek, de lijn boven het oor, de overgang naar de baard. Daarvoor heb je scherp gereedschap nodig en een vaste hand.', ''),
 ('Scheren zoals het hoort', 'Voor een scheerbeurt wordt de huid eerst warm en zacht gemaakt, met een warme handdoek. Zo glijdt het mes makkelijker en heeft je huid er minder last van. Daarna: scheerschuim, een scherp mes, rustig werken.', ''),
 ('Verzorging voor je baard', 'Na het trimmen of scheren hoort er verzorging bij. Een paar druppels baardolie maken het haar zacht en de huid eronder minder droog. Vraag gerust welke producten bij jouw baard passen.', ''),
 ('Jouw stoel staat klaar', 'Kies online een dienst en een tijd, of bel even — dan staat de stoel klaar als je binnenkomt.', ''),
]
TOTAL = len(CH) + 1

def index():
    cards = ''.join(f'<article class="fcard glow-follow {pos}"><span class="no">Ferry · {i+1:02d} / {TOTAL:02d}</span><b>{h}</b><p>{p}</p><button class="more" type="button" aria-expanded="false">lees verder +</button></article>' for i, (h, p, pos) in enumerate(CARDS))
    imgs = ['k1', 'k2', 'k7', 'k3', 'k4', 'k6', 'k5', 'k7']
    still_items = []
    for i, (c, (h, p, _)) in enumerate(zip(CH, CARDS)):
        inner = ''
        if i == 0:
            inner += f'<span class="chip">Barbershop · {ADR}</span><h1 style="margin-top:14px">strak geknipt aan de Stationsstraat.</h1><p class="lead">{HERO_LEAD}</p><div class="row">{B_BOEK()}{B_TEL()}</div><hr style="border:0;height:1px;background:var(--line);margin:22px 0">'
        inner += f'<h2>{c["t"]}</h2><p class="note">{c["s"]}</p><p>{p}</p>'
        cap = 'Sfeerbeeld — niet de echte gevel' if i == 0 else 'Sfeerbeeld'
        still_items.append((f'assets/img/{imgs[i]}.webp', f'assets/img/{imgs[i]}-m.webp', inner, cap))
    chj = json.dumps(CH, ensure_ascii=False)
    hotspots = [
     ('Kam &amp; schaar', 'Voor de bovenkant, de lengte en het bijwerken van de details.', 'diensten.html#knippen', 'Bekijk: knippen', .15, .5),
     ('Tondeuse', 'Met opzetkammen van kort naar lang — zo ontstaat een fade.', 'diensten.html#knippen', 'Bekijk: knippen', .3, .5),
     ('Trimmer', 'Voor strakke lijnen in de nek en langs de baard.', 'diensten.html#baard', 'Bekijk: baard trimmen', .43, .5),
     ('Baardolie', 'Een paar druppels na het trimmen: zacht haar, rustige huid.', 'diensten.html#baard', 'Bekijk: baard trimmen', .555, .5),
     ('Scheermes', 'Voor een gladde scheerbeurt, na een warme handdoek.', 'diensten.html#scheren', 'Bekijk: baard scheren', .675, .5),
     ('Handdoek', 'Warm voor het scheren, koel en fris erna.', 'diensten.html#scheren', 'Bekijk: baard scheren', .84, .48),
    ]
    hots = ''.join(f'<button class="hot" type="button" style="--x:{x*100:.1f}%;--y:{y*100:.1f}%" aria-pressed="{"true" if k==0 else "false"}" aria-label="{html.unescape(n)}" data-n="{html.unescape(n)}" data-t="{t}" data-h="{h}" data-l="{l}"></button>' for k, (n, t, h, l, x, y) in enumerate(hotspots))
    lijst = ''.join(f'<li><b>{n}</b> — {t} <a href="{h}" style="color:var(--sky)">{l}</a></li>' for n, t, h, l, x, y in hotspots)
    n0, t0, h0, l0 = hotspots[0][:4]
    PANO = [('knippen', 'Knippen', 'Je haar weer in model: kort, een fade of netjes bijgewerkt.', .22),
            ('knippen-baard', 'Knippen &amp; baard', 'Haar en baard in één keer, alles weer in balans.', .3),
            ('baard', 'Baard trimmen', 'Op lengte en in vorm, met strakke lijnen.', .43),
            ('scheren', 'Baard scheren', 'Glad, na een warme handdoek.', .675)]
    panels = ''.join(f'<a class="panel" href="diensten.html#{i}" style="text-decoration:none"><div class="crop"><img src="assets/img/d1.webp" alt="" loading="lazy" style="--c:{c}"><span class="cap mono">Sfeerbeeld</span></div><h3>{n}</h3><p>{t}</p></a>' for i, n, t, c in PANO)
    WIJ = [('knippen', 'een frisse coupe', 'Knippen', 'Je haar weer in vorm — kort, met een fade of gewoon netjes bijgewerkt.', .22),
           ('knippen-baard', 'alles in één keer', 'Knippen &amp; baard trimmen', 'Haar en baard samen, zodat de overgang klopt.', .3),
           ('baard', 'mijn baard netjes', 'Baard trimmen', 'Op lengte, in model, strakke lijnen langs wang en nek.', .43),
           ('scheren', 'helemaal glad', 'Baard scheren', 'Warme handdoek, scherp mes, rustig werken.', .675)]
    chips = ''.join(f'<button class="schip" type="button" aria-pressed="{"true" if k==0 else "false"}" data-id="{i}" data-n="{html.unescape(n)}" data-t="{t}" data-c="{c}" data-tag="Dienst">{ch}</button>' for k, (i, ch, n, t, c) in enumerate(WIJ))
    w0 = WIJ[0]
    return head('Barbershop Ferry — barbier aan de Stationsstraat in Waalwijk',
                'Barbershop Ferry, Stationsstraat 130 in Waalwijk. Knippen, baard trimmen en baard scheren. Plan je afspraak online of bel 06 28 71 89 27.') + header('index.html') + f'''<section class="film" data-src="{FILM_SRC}" data-src-m="{FILM_SRC_M}" data-seg="{{SEG}}" data-seg-m="{{SEGM}}" data-poster-m="assets/img/film-main-m-0.webp" data-hud="Ferry" data-total="{TOTAL}" data-dur="{SEGS.get('dur', 28)}" data-portal style="--m:{len(CH)+1}" aria-label="Barbershop Ferry — van de barberpaal aan de Stationsstraat tot de stoel die klaarstaat">
  <div class="stage">
    <video poster="assets/img/film-main-0.webp" muted playsinline preload="none" aria-hidden="true"></video>
    <div class="vignette"></div>
    <canvas class="fx" aria-hidden="true"></canvas>
    <div class="fhero">
      <div class="top"><span class="chip">Barbershop · {ADR}</span><h1>strak geknipt aan de Stationsstraat.</h1></div>
      <div class="low glow-follow">
        <p class="lead">{HERO_LEAD}</p>
        <div class="row">{B_BOEK()}{B_TEL()}</div>
        <p class="hmeta mono"><a href="{ROUTE}" target="_blank" rel="noopener">{ADR} · {PC}</a></p>
      </div>
    </div>
    <div class="ftitle tc" aria-live="polite"><h2></h2><p></p></div>
    {cards}
    <div class="hud mono" aria-hidden="true"><span class="hl">Ferry · 01 / {TOTAL:02d}</span><span class="sf">Sfeerbeeld</span><span class="tc">00:00 / 00:28</span><span class="load"><s></s></span></div>
    <div class="pole" aria-hidden="true"><i></i></div>
    <span class="ftag mono">Sfeerbeeld</span>
    <div class="fhint">scroll — de paal draait, de stoel staat klaar</div>
  </div>
  {fstills(still_items)}
  <script type="application/json">{chj}</script>
</section>
<section class="portal" data-a="assets/img/film-main-end.webp" data-a-m="assets/img/film-main-m-end.webp" data-b="assets/img/k8.webp" data-b-m="assets/img/k8-m.webp" data-g="[0.5,0.42]" data-g-m="[0.5,0.42]" aria-label="Tot zo aan de Stationsstraat">
  <div class="pstage">
    <img class="pfb a" alt="">
    <img class="pfb b" src="assets/img/k8.webp" alt="Een barbershop in de schemering: het raam gloeit warm, de barberpaal brandt">
    <canvas class="gl" aria-hidden="true"></canvas>
    <canvas class="dust" data-k="warm" aria-hidden="true"></canvas>
    <div class="ptext glow-follow">
      <span class="eyebrow">Ferry · Waalwijk</span>
      <h2>tot zo aan de Stationsstraat.</h2>
      <p class="p1">Als het buiten donker wordt, brandt binnen nog het licht en draait de paal nog even door. Of je nu komt voor een fade, een baard die weer in model moet of een gladde scheerbeurt — bij Barbershop Ferry aan de Stationsstraat in Waalwijk ben je welkom.</p>
      <p class="p2">Een afspraak maken hoeft niet ingewikkeld te zijn. Kies wat je wilt laten doen, kies een dag en een tijd, laat je naam en nummer achter. Liever even bellen? Dat kan natuurlijk ook: {TELT}.</p>
      <button class="more" type="button" aria-expanded="false">lees verder +</button>
      <div class="row">{B_BOEK()}{B_TEL()}</div>
    </div>
    <span class="phud mono">Ferry · {TOTAL:02d} / {TOTAL:02d}<span class="sf">Sfeerbeeld</span></span>
    <span class="ptag mono">Sfeerbeeld — niet de echte gevel</span>
    <div class="pdark"></div>
  </div>
</section>

<section class="dark-band seam-bot" id="vak" style="--to:var(--foam)">
  <canvas class="dust" data-k="gold" aria-hidden="true"></canvas>
  <div class="wrap j1">
    <div>
      <span class="eyebrow">Het vak</span>
      <h2 class="words">een barbier kijkt eerst.</h2>
      <div class="prose rv">
        <p>Een goede knipbeurt begint niet met de tondeuse, maar met kijken. Hoe groeit je haar, waar zit de kruin, hoe draag je het normaal en wat zit je nu dwars? Wil je het kort aan de zijkant en langer bovenop, of juist overal even kort? Pas als dat duidelijk is, gaat de cape om.</p>
        <p>Daarna is het handwerk. Een fade maak je in stappen, met opzetkammen van klein naar groot, tot de overgang zo vloeiend is dat je geen lijn meer ziet. Met de schaar komt de vorm bovenop, met de trimmer de strakke lijnen in de nek en langs het oor. Voor de baard hetzelfde: eerst de lengte, dan de lijnen, en een paar druppels olie om af te maken.</p>
        <p>En dan is er de rust. Bij de barbier hoef je even niets. Je zit, er wordt voor je gezorgd, en je loopt naar buiten met haar dat weer helemaal klopt.</p>
      </div>
    </div>
    <div class="lade rv" style="--d:1">
      <span class="eyebrow">Op het werkblad — tik op een punt</span>
      <figure class="fig breathe"><img src="assets/img/d1.webp" alt="Kam en schaar, tondeuse, trimmer, flesje baardolie, scheermes en een handdoek op een mintgroen terrazzo werkblad" loading="lazy">{hots}<figcaption class="cap mono">Sfeerbeeld</figcaption></figure>
      <div class="tagcard" aria-live="polite"><b>{html.unescape(n0)}</b><p>{t0}</p><a href="{h0}">{l0}</a></div>
      <ul class="ladelist">{lijst}</ul>
      <p class="note">Sfeerbeeld — welk gereedschap en welke producten er gebruikt worden, zie je in de zaak.</p>
    </div>
  </div>
</section>

<section class="pano" id="diensten" aria-label="Wat je hier kunt laten doen">
  <div class="pin">
    <div class="head">
      <div><span class="eyebrow">Diensten</span><h2 class="words">vier dingen, goed gedaan.</h2></div>
      <p class="rv">Vier diensten: knippen, knippen met baard trimmen, baard trimmen en baard scheren. De prijs zie je bij het boeken of hoor je in de zaak.</p>
    </div>
    <div class="track">{panels}<div class="panel end"><span class="mono">Prijzen: op aanvraag — zie Fresha of bel even</span><ul>{''.join(f'<li><a href="diensten.html#{i}">{n}</a></li>' for i, n, t, c in PANO)}</ul>{btn('diensten.html', 'Alle diensten', '', 'cut')}</div></div>
    <div class="pbar"><i></i></div>
  </div>
</section>

<section class="bg-marble seam-top seam-bot" id="stijlwijzer" style="--from:var(--foam);--to:var(--foam)">
  <div class="wrap wijzer">
    <div>
      <span class="eyebrow">Stijlwijzer</span>
      <h2 class="words">wat wil je vandaag?</h2>
      <p class="lead rv" style="margin-top:18px">Twijfel je wat je moet kiezen? Tik aan wat je zoekt, dan zie je welke dienst erbij past — en plan je hem meteen.</p>
      <div class="chips rv" role="group" aria-label="Wat zoek je?">{chips}</div>
      <p class="note rv">Een suggestie, geen advies — in de stoel kijkt de barbier altijd even met je mee.</p>
    </div>
    <div class="wout rv" style="--d:1" aria-live="polite">
      <div class="crop"><img src="assets/img/d1.webp" alt="" loading="lazy" style="--c:{w0[4]}"><span class="cap mono">Sfeerbeeld</span></div>
      <div class="body"><small>Dienst</small><b>{w0[2]}</b><p>{w0[3]}</p><div class="row">{btn('afspraak.html?dienst=' + w0[0], 'Plan dit', '', 'cal')}</div></div>
    </div>
  </div>
</section>

<section class="bg-foam" id="online">
  <div class="wrap">
    <span class="eyebrow">Online afspraak</span>
    <h2 class="words">in vier tikken geregeld.</h2>
    <p class="lead rv" style="margin-top:18px">Geen gedoe met terugbellen. Je kiest zelf wanneer het jou uitkomt, ook 's avonds op de bank of in je pauze.</p>
    <div class="path">
      <svg viewBox="0 0 1200 90" aria-hidden="true"><path d="M20 60 C 200 10, 330 85, 480 45 S 760 10, 880 50 S 1100 80, 1180 30" fill="none" stroke="rgba(23,35,63,.12)" stroke-width="2"/><path class="draw" d="M20 60 C 200 10, 330 85, 480 45 S 760 10, 880 50 S 1100 80, 1180 30" fill="none" stroke="#C42032" stroke-width="2.5" stroke-linecap="round"/><circle class="dot" cx="20" cy="60" r="9" fill="#C42032" stroke="#F5F3EE" stroke-width="3"/></svg>
      <ol class="steps"><li><span class="n">01</span><b>Dienst</b>Knippen, baard of allebei?</li><li><span class="n">02</span><b>Dag &amp; tijd</b>Kies wat jou uitkomt.</li><li><span class="n">03</span><b>Je gegevens</b>Naam en telefoonnummer, meer niet.</li><li><span class="n">04</span><b>Bevestigd</b>Je ziet meteen je afspraak terug.</li></ol>
    </div>
    <div class="row rv">{B_BOEK()}</div>
  </div>
</section>

<section class="bg-marble seam-top" id="adres" style="--from:var(--foam)">
  <div class="wrap waar">
    <div class="paalorn rv" aria-hidden="true"></div>
    <div>
      <span class="eyebrow">Adres</span>
      <h2 class="words">aan de Stationsstraat.</h2>
      <div class="prose rv">
        <p>Je vindt Barbershop Ferry aan de Stationsstraat 130 in Waalwijk. Kom je met de fiets of loop je even binnen? Plan dan vooraf je afspraak, dan staat de stoel klaar als je er bent.</p>
        <p>Wil je weten wanneer je terecht kunt? Kies online een dag en tijd, of bel even.</p>
      </div>
      <div class="row rv">{B_ROUTE('')}{B_WA()}</div>
    </div>
    <div class="gplates rv" style="--d:1">
      <a class="plate glow-follow" href="{ROUTE}" target="_blank" rel="noopener">{I['pin']}<span>{ADR}<small>{PC}</small></span></a>
      <a class="plate glow-follow" href="{TEL}">{I['tel']}<span>{TELT}<small>bellen</small></span></a>
      <a class="plate glow-follow" href="{WA}" target="_blank" rel="noopener">{I['wa']}<span>WhatsApp<small>nog te bevestigen</small></span></a>
      <a class="plate glow-follow" href="afspraak.html">{I['cal']}<span>Online afspraak<small>in een minuut</small></span></a>
    </div>
  </div>
</section>
''' + finale('var(--marble)', ('assets/img/k6.webp', 'assets/img/k6-m.webp', 'Sfeerbeeld', '')) + footer()

# ======================================================================= DIENSTEN
SVCX = [
 ('knippen', 'knippen.', .22, ['Knippen bij de barbier begint met een korte vraag: hoe draag je je haar, wat moet eraf en wat mag blijven? Daarna gaat de tondeuse aan het werk, met opzetkammen van kort naar lang. Zo maak je een fade: onderaan bijna niets, naar boven toe steeds meer, zonder zichtbare lijn.', 'Bovenop komt de vorm met schaar en kam. Tot slot de details: de nek strak, de lijn rond het oor, even checken in de spiegel. Liever klassiek kort, een crop of alleen de punten? Zeg het gerust — dan wordt het precies zoals jij het draagt.']),
 ('knippen-baard', 'knippen &amp; baard trimmen.', .3, ['Haar en baard horen bij elkaar. Als je je haar laat knippen maar de baard laat zitten, klopt de overgang vaak niet meer. Daarom kun je bij Ferry allebei in één afspraak laten doen: eerst het haar, dan de baard.', 'De baard wordt op lengte gebracht en in vorm getrimd, met strakke lijnen langs de wang en in de nek. De overgang van je bakkebaarden naar de baard loopt mooi in elkaar over. Zo loop je naar buiten als één geheel.']),
 ('baard', 'baard trimmen.', .43, ['Een baard groeit nooit helemaal gelijk. Op de ene plek sneller dan op de andere, en de lijnen vervagen na een paar weken. Bij het trimmen wordt je baard weer op lengte gebracht en in model gezet — vol waar het moet, kort waar het netter is.', 'Daarna de lijnen: langs de wangen, onder de kaak en in de nek. Een paar druppels baardolie maken het af: zacht haar en een huid die niet trekt. Welke producten Ferry gebruikt, hoor je in de zaak.']),
 ('scheren', 'baard scheren.', .675, ['Glad scheren is een vak apart. Eerst gaat er een warme handdoek op je gezicht. Die maakt de huid en de haren zacht, zodat het mes makkelijker glijdt en je huid minder geïrriteerd raakt.', 'Daarna scheerschuim en een scherp mes, rustig en met de groeirichting mee. Tot slot iets verkoelends voor de huid. Het resultaat: glad, fris en verzorgd — en een kwartiertje waarin je even helemaal niets hoeft.']),
]
PANCH = [dict(t='kam &amp; schaar.', s='', c=.15, z=1.6, zm=1.25), dict(t='tondeuse.', s='', c=.3, z=1.6, zm=1.25), dict(t='trimmer.', s='', c=.43, z=1.6, zm=1.25),
         dict(t='baardolie.', s='', c=.555, z=1.6, zm=1.25), dict(t='scheermes.', s='', c=.675, z=1.6, zm=1.25)]
for c in PANCH: c.update(fx='dust', pos='tl', at=0)

def diensten():
    svc = ''
    for k, (i, h, c, ps) in enumerate(SVCX):
        svc += f'''<article class="svc{' rev' if k % 2 else ''}" id="{i}">
      <figure class="fig breathe rv"><img src="assets/img/d1.webp" alt="" loading="lazy" style="--c:{c}"><figcaption class="cap mono">Sfeerbeeld</figcaption></figure>
      <div><h2 class="words">{h}</h2><div class="prose rv">{''.join(f'<p>{p}</p>' for p in ps)}</div><div class="row rv">{btn('afspraak.html?dienst=' + i, 'Plan deze dienst', '', 'cal')}</div></div>
    </article>
'''
    marq_items = '<span>knippen</span><i></i><span>fade</span><i></i><span>baard trimmen</span><i></i><span>baard scheren</span><i></i><span>warme handdoek</span><i></i><em>stationsstraat 130</em><i></i>'
    stills = [('assets/img/d1.webp', 'assets/img/d1-m.webp', f'<span class="chip">Diensten</span><h1 style="margin-top:14px">wat er in de stoel gebeurt.</h1><p class="lead">Knippen, knippen met baard, baard trimmen en baard scheren — de vier diensten van Barbershop Ferry. Hieronder lees je wat er gebeurt, en plan je meteen.</p><div class="row">{B_BOEK()}{B_TEL()}</div>', 'Sfeerbeeld')]
    return head('Diensten — Barbershop Ferry, Waalwijk', 'Knippen, knippen &amp; baard trimmen, baard trimmen en baard scheren bij Barbershop Ferry, Stationsstraat 130 Waalwijk. Prijs op aanvraag.', 'assets/img/d1.webp') + header('diensten.html') + f'''<section class="pan" data-hud="Diensten" style="--m:6" aria-label="Diensten — de camera glijdt over het werkblad">
  <div class="stage">
    <img class="flat" src="assets/img/d1.webp" width="1344" height="752" alt="Barbiersgereedschap op een mintgroen terrazzo werkblad: kam en schaar, tondeuse, trimmer, baardolie, scheermes en een handdoek">
    <div class="vignette"></div>
    <canvas class="fx" aria-hidden="true"></canvas>
    <div class="phead">
      <div class="top"><span class="chip">Diensten</span><h1>wat er in de stoel gebeurt.</h1></div>
      <div class="bot glow-follow"><p class="lead">Knippen, knippen met baard, baard trimmen en baard scheren — de vier diensten van Barbershop Ferry. Hieronder lees je wat er gebeurt, en plan je meteen.</p><div class="row">{B_BOEK()}{B_TEL()}</div></div>
    </div>
    <div class="ftitle" aria-live="polite"><h2></h2><p></p></div>
    <div class="hud mono" aria-hidden="true"><span class="hl">Diensten · 01 / 05</span><span class="sf">Sfeerbeeld</span></div>
    <div class="pole" aria-hidden="true"><i></i></div>
    <span class="ftag mono">Sfeerbeeld</span>
    <div class="fade"></div>
  </div>
  {fstills(stills)}
  <script type="application/json">{json.dumps(PANCH, ensure_ascii=False)}</script>
</section>
<section class="bg-foam" style="padding-bottom:0">
  <div class="wrap">
    <p class="honest rv">Vier diensten, alle vier online te boeken. Prijs op aanvraag — je ziet de prijs bij het boeken, of je hoort hem als je even belt.</p>
    {svc}
  </div>
</section>
<div class="marq" aria-label="Diensten"><div>{marq_items * 4}</div></div>
<section class="bg-foam">
  <div class="wrap prijs rv">
    <div><h3 style="font-size:clamp(2.2rem,3.6vw,3.2rem)">wat kost het?</h3><p class="lead" style="margin-top:12px">De prijs zie je bij het boeken, of je vraagt het even aan de telefoon. Knippen met baard is één afspraak — handig als je alles in één keer wilt laten doen.</p></div>
    <div class="row" style="margin-top:0">{B_TEL('')}{B_WA()}</div>
  </div>
</section>
''' + finale('var(--foam)', ('assets/img/k4.webp', 'assets/img/k4-m.webp', 'Sfeerbeeld', 'left')) + footer()

# ======================================================================= AFSPRAAK
def afspraak():
    opts = ''.join(f'<label class="opt"><input type="radio" name="dienst" value="{i}" data-n="{html.unescape(n)}"><b>{n}</b><span>{t}</span><small><em style="font-style:normal">prijs op aanvraag</em></small></label>' for i, n, en, t in SVC)
    faq = [('Wanneer kan ik terecht?', 'Bel even of kies online een dag en tijd — dan weet je meteen wanneer er plek is.'),
           ('Hoe lang duurt een knipbeurt?', 'Dat hangt af van wat je wilt laten doen. Knippen met baard duurt langer dan alleen trimmen; bij het boeken zie je het precies.'),
           ('Kan ik mijn afspraak verzetten?', f'Bel even naar {TELT}, dan zoek je samen een nieuw moment.'),
           ('Wat kost het?', 'De prijs zie je bij het boeken, of je hoort hem als je belt.')]
    faqh = ''.join(f'<details><summary>{q}</summary><p>{a}</p></details>' for q, a in faq)
    return head('Afspraak maken — Barbershop Ferry, Waalwijk', 'Plan je afspraak bij Barbershop Ferry, Stationsstraat 130 Waalwijk: kies een dienst, een dag en een tijd. Of bel 06 28 71 89 27.', 'assets/img/a1.webp') + header('afspraak.html') + f'''<section class="phero split" style="--to:var(--foam)" aria-label="Online afspraak">
  <div class="bg"><div class="kbw" data-kb><picture><source media="(max-width:760px)" srcset="assets/img/a1-m.webp"><img src="assets/img/loop-afspraak-0.webp" alt="Een houten bankje bij het raam met een opgevouwen mintgroene kapmantel en een plantje" fetchpriority="high"></picture><video data-auto data-src="assets/loop-afspraak.mp4" poster="assets/img/loop-afspraak-0.webp" muted playsinline loop preload="none" aria-hidden="true" class="dv"></video></div></div>
  <canvas class="dust" data-k="cool" aria-hidden="true"></canvas>
  <span class="cap mono">Sfeerbeeld</span>
  <div class="wrap"><div class="box">
    <span class="chip">Online afspraak</span>
    <h1 class="words" style="margin-top:16px">plan je stoel.</h1>
    <p class="lead rv">Kies wat je wilt laten doen, kies een dag en tijd die jou uitkomt en laat je gegevens achter. Klaar in een minuut.</p>
    <span class="demo-plate rv">Demo — er wordt niets geboekt</span>
  </div></div>
</section>

<section class="bg-foam" id="boeken" style="padding-top:clamp(40px,8vh,80px)">
  <div class="wrap book" id="wizard">
    <div>
      <ol class="wbar" aria-label="Stappen">
        <li class="cur"><button type="button" disabled>1 Dienst</button></li><li><button type="button" disabled>2 Dag &amp; tijd</button></li><li><button type="button" disabled>3 Je gegevens</button></li><li><button type="button" disabled>4 Bevestigd</button></li>
      </ol>
      <noscript><p class="honest">Zonder JavaScript werkt de demo-afspraak niet. Bel {TELT}.</p></noscript>
      <div class="wstep" data-s="1">
        <h2>wat wil je laten doen?</h2>
        <fieldset style="border:0"><legend class="sr">Kies een dienst</legend><div class="opts">{opts}</div></fieldset>
        <p class="note">Prijs op aanvraag — je hoort hem in de zaak.</p>
        <span class="err" id="e1" role="alert"></span>
        <div class="wnav"><button class="btn" type="button" id="n1">Volgende</button></div>
      </div>
      <div class="wstep" data-s="2" hidden>
        <h2>wanneer komt het je uit?</h2>
        <span class="lbl" id="l-dag">Kies een dag</span>
        <div class="days" id="days" role="group" aria-labelledby="l-dag"></div>
        <span class="lbl" id="l-tijd">Kies een tijd</span>
        <div class="slots" id="slots" role="group" aria-labelledby="l-tijd"></div>
        <p class="note">Demo — voorbeeldtijden, er wordt niets geboekt.</p>
        <span class="err" id="e2" role="alert"></span>
        <div class="wnav"><button class="btn ghost" type="button" id="b2">Terug</button><button class="btn" type="button" id="n2">Volgende</button></div>
      </div>
      <div class="wstep" data-s="3" hidden>
        <h2>op welke naam?</h2>
        <form id="gegevens" novalidate>
          <div class="fields">
            <label class="fld">Naam*<input name="naam" autocomplete="name" placeholder="Voor- en achternaam" required><span class="ferr" aria-live="polite"></span></label>
            <label class="fld">Telefoon*<input name="tel" type="tel" autocomplete="tel" inputmode="tel" placeholder="06 12 34 56 78" required><span class="ferr" aria-live="polite"></span></label>
            <label class="fld full">E-mail (optioneel)<input name="mail" type="email" autocomplete="email" placeholder="naam@voorbeeld.nl"></label>
            <label class="fld full">Opmerking (optioneel)<textarea name="opm" placeholder="bijv. skin fade, bovenop 3 cm eraf"></textarea></label>
            <label class="check full"><input type="checkbox" name="rem"> Stuur me een herinnering (demo)</label>
          </div>
          <p class="priv">We gebruiken je gegevens alleen voor je afspraak. (In deze demo wordt niets verstuurd of opgeslagen.)</p>
          <div class="wnav"><button class="btn ghost" type="button" id="b3">Terug</button><button class="btn" type="submit">Afspraak bevestigen</button></div>
        </form>
      </div>
      <div class="wstep" data-s="4" hidden>
        <h2>tot dan.</h2>
        <div class="receipt">
          <dl><dt>Dienst</dt><dd id="r-dienst"></dd><dt>Dag</dt><dd id="r-dag"></dd><dt>Tijd</dt><dd id="r-tijd"></dd><dt>Naam</dt><dd id="r-naam"></dd><dt>Waar</dt><dd>{ADR}, Waalwijk</dd></dl>
        </div>
        <p class="honestbox"><strong>Ontwerpvoorstel.</strong> Er is niets geboekt en niets verstuurd — dit is een demo van de online afspraak. Wil je nu echt een afspraak? Bel {TELT}.</p>
        <div class="row"><button class="btn" type="button" id="ics">{I['cal']}Zet in agenda (.ics)</button>{B_TEL()}<button class="btn ghost" type="button" id="nieuw">Nieuwe afspraak</button></div>
      </div>
    </div>
    <aside class="aside" id="aside" aria-live="polite">
      <h3>Jouw afspraak</h3>
      <p class="empty">Nog niets gekozen.</p>
      <dl hidden><dt>Dienst</dt><dd id="s-dienst"></dd><dt>Dag</dt><dd id="s-dag"></dd><dt>Tijd</dt><dd id="s-tijd"></dd></dl>
      <p class="note">Demo — er wordt niets geboekt</p>
    </aside>
  </div>
</section>

<section class="bg-marble seam-top" style="--from:var(--foam)">
  <div class="wrap two">
    <div>
      <h2 class="words">liever even bellen?</h2>
      <p class="lead rv" style="margin-top:16px">Geen probleem. Bel {TELT}. Je vindt de zaak aan de Stationsstraat 130 in Waalwijk.</p>
      <div class="row rv">{B_TEL('')}{B_WA()}</div>
    </div>
    <div class="rv" style="--d:1"><span class="eyebrow">Kort &amp; handig</span>{faqh}</div>
  </div>
</section>
''' + finale('var(--marble)', ('assets/img/b2.webp', 'assets/img/b2-m.webp', 'Sfeerbeeld', 'left')) + footer('<script src="assets/booking.js"></script>\n')

# ======================================================================= OVER ONS
OCH = [dict(t='alles ligt klaar.', s='Tondeuse, opzetkammen, kam, een schone handdoek.', fx='dust', at=1.3, pos='tc', cx=.4),
       dict(t='kom binnen, ga zitten.', s='Een bankje, een cape, even wachten.', fx='dust', warm=1, at=5.1, pos='tl', cx=.74)]

def over():
    stills = [('assets/img/b1.webp', 'assets/img/b1-m.webp', f'<span class="chip">Barbier in Waalwijk</span><h1 style="margin-top:14px">een barbier om de hoek.</h1><p class="lead">Barbershop Ferry is een barbier aan de Stationsstraat in Waalwijk. Een plek om even te zitten, goed geholpen te worden en strak weer naar buiten te lopen.</p><div class="row">{B_BOEK()}{btn("diensten.html", "Bekijk diensten", "ghost")}</div><h2 style="margin-top:22px">{OCH[0]["t"]}</h2><p class="note">{OCH[0]["s"]}</p>', 'Sfeerbeeld'),
              ('assets/img/a1.webp', 'assets/img/a1-m.webp', f'<h2>{OCH[1]["t"]}</h2><p class="note">{OCH[1]["s"]}</p>', 'Sfeerbeeld')]
    plaques = ''.join(f'<div class="plaque rv" style="--d:{k}"><i></i><i></i><i></i><i></i><span>Vraag {k+1:02d}</span><b>{q}</b></div>' for k, q in enumerate(['Wie is Ferry?', 'Sinds wanneer aan de Stationsstraat?', 'Waar ben je trots op?']))
    return head('Over ons — Barbershop Ferry, Waalwijk', 'Barbershop Ferry aan de Stationsstraat 130 in Waalwijk: een barbier om de hoek voor knippen, baard trimmen en scheren.', 'assets/img/b1.webp') + header('over-ons.html') + f'''<section class="film" data-src="assets/film-over.mp4" data-src-m="assets/film-over-m.mp4" data-poster-m="assets/img/film-over-m-0.webp" data-hud="Ferry" data-dur="5.6" style="--m:3" aria-label="Het werkblad met gereedschap, en een bankje bij het raam">
  <div class="stage">
    <video poster="assets/img/film-over-0.webp" muted playsinline preload="none" aria-hidden="true"></video>
    <div class="vignette"></div>
    <canvas class="fx" aria-hidden="true"></canvas>
    <div class="fhero">
      <div class="top sky"><span class="chip">Barbier in Waalwijk</span><h1>een barbier om de hoek.</h1></div>
      <div class="low left glow-follow"><p class="lead">Barbershop Ferry is een barbier aan de Stationsstraat in Waalwijk. Een plek om even te zitten, goed geholpen te worden en strak weer naar buiten te lopen.</p><div class="row">{B_BOEK()}{btn("diensten.html", "Bekijk diensten", "ghost")}</div></div>
    </div>
    <div class="ftitle tc" aria-live="polite"><h2></h2><p></p></div>
    <div class="hud mono" aria-hidden="true"><span class="hl">Ferry · 01 / 02</span><span class="sf">Sfeerbeeld</span><span class="tc">00:00 / 00:05</span><span class="load"><s></s></span></div>
    <div class="pole" aria-hidden="true"><i></i></div>
    <span class="ftag mono">Sfeerbeeld</span>
    <div class="fhint c">scroll — kom binnen</div>
    <div class="fade"></div>
  </div>
  {fstills(stills)}
  <script type="application/json">{json.dumps(OCH, ensure_ascii=False)}</script>
</section>

<section class="bg-foam">
  <div class="wrap split">
    <div>
      <span class="eyebrow">Een barbier aan de Stationsstraat</span>
      <h2 class="words">meer dan een knipbeurt.</h2>
      <div class="prose rv">
        <p>Een barbershop is een bijzonder soort plek. Je komt voor je haar of je baard, maar je blijft even voor de rust. De cape gaat om, de tondeuse zoemt, en een tijdje hoef je niets anders dan stilzitten. Voor veel mannen is dat het enige kwartier in de week waarin iemand anders voor hen zorgt.</p>
        <p>Het vak zelf is eenvoudig te beschrijven en moeilijk om goed te doen: een fade zonder lijn, een nek die strak blijft, een baard die bij je gezicht past, een scheerbeurt zonder irritatie. Dat vraagt om goed gereedschap, een vaste hand en tijd.</p>
        <p>Barbershop Ferry zit aan de Stationsstraat 130 in Waalwijk: knippen, knippen met baard, baard trimmen en baard scheren. Loop gerust even binnen, of bel {TELT}.</p>
      </div>
    </div>
    <figure class="fig rv" style="aspect-ratio:4/5;--d:1"><img data-par="60" src="assets/img/k4.webp" alt="Het mes van een tondeuse in het ochtendlicht, met zwevend haarstof" loading="lazy" style="object-position:48% 50%"><figcaption class="cap mono">Sfeerbeeld</figcaption></figure>
  </div>
</section>

<section class="bg-foam seam-bot" style="--to:var(--bordeaux);padding-top:0">
  <div class="wrap">
    <span class="eyebrow">Waarom naar de barbier?</span>
    <div class="fill"><p>Omdat een fade pas mooi is zonder lijn.</p><p>Omdat een baard ook verzorging nodig heeft.</p><p>Omdat even zitten ook goed is.</p></div>
  </div>
</section>

<section class="dark-band seam-bot" style="--to:var(--foam)">
  <canvas class="dust" data-k="gold" aria-hidden="true"></canvas>
  <div class="wrap split">
    <div>
      <span class="eyebrow">Het verhaal van Ferry</span>
      <h2 class="words">dit verhaal vertelt Ferry zelf.</h2>
      <div class="plaques">{plaques}</div>
      <p class="note rv">Ontwerpvoorstel: hier komt het echte verhaal van de zaak.</p>
    </div>
    <figure class="fig breathe rv" style="aspect-ratio:4/5;--d:1"><picture><source media="(max-width:760px)" srcset="assets/img/k7-m.webp"><img src="assets/img/k7.webp" alt="Een lege kersenrode barbiersstoel tegen een wand van mintgroene tegels" loading="lazy" style="object-position:50% 50%"></picture><figcaption class="cap mono">Sfeerbeeld</figcaption></figure>
  </div>
</section>

<section class="bg-foam">
  <div class="wrap">
    <div class="igblock">
      <div class="igring rv" aria-hidden="true"><span>{I['cal']}</span></div>
      <div>
        <h3 class="words" style="font-size:clamp(2.2rem,3.8vw,3.4rem)">online je tijd kiezen.</h3>
        <p class="lead rv" style="margin-top:14px">Geen wachtrij, geen terugbellen: kies je dienst, een dag en een tijd, en je stoel staat klaar.</p>
        <div class="row rv">{B_BOEK('Afspraak maken', '')}</div>
      </div>
    </div>
    <p class="placeholder rv">Hier komen foto's van de zaak, de stoelen en het werk van Ferry.</p>
  </div>
</section>
''' + finale('var(--foam)', ('assets/img/k3.webp', 'assets/img/k3-m.webp', 'Sfeerbeeld', '')) + footer()

# ======================================================================= CONTACT
def contact():
    faq = [('Hoe maak ik een afspraak?', f'Online via de afspraakpagina, of bel {TELT}.'),
           ('Wanneer kan ik langskomen?', 'Kies online een dag en tijd, of bel even.'),
           ('Kan ik mijn fiets kwijt of parkeren?', 'Dat hoor je het snelst als je even belt.'),
           ('Kan ik ook WhatsAppen?', 'Waarschijnlijk via hetzelfde nummer — dat bevestigen we nog met de zaak. Bellen werkt in elk geval.')]
    faqh = ''.join(f'<details><summary>{q}</summary><p>{a}</p></details>' for q, a in faq)
    blocks = ''
    import random
    rnd = random.Random(7)
    for gx in range(0, 8):
        for gy in range(0, 6):
            x, y = 20 + gx * 100, 20 + gy * 100
            if gy == 3 or gx == 5: continue
            w, h = 76 + rnd.randint(-6, 4), 76 + rnd.randint(-6, 4)
            blocks += f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="10" fill="#E3ECE6"/>'
    mapsvg = f'''<svg viewBox="0 0 800 600" role="img" aria-label="Schematische kaart: Stationsstraat 130, Waalwijk">
      <rect width="800" height="600" fill="#F5F3EE"/>{blocks}
      <rect x="0" y="312" width="800" height="62" fill="#fff"/><path d="M0 343H800" stroke="#C42032" stroke-width="1.5" stroke-dasharray="2 10" opacity=".6"/>
      <rect x="512" y="0" width="62" height="600" fill="#fff"/>
      <path class="route" d="M40 343 H 400" stroke="#17233F" stroke-width="3" fill="none" opacity=".5"/>
      <text x="60" y="334" font-family="Spline Sans Mono, monospace" font-size="13" letter-spacing="2.5" fill="#4E5A72">STATIONSSTRAAT</text>
      <circle class="ring" cx="420" cy="343" r="22" fill="none" stroke="#C42032" stroke-width="2"/>
      <g class="pin"><path d="M420 343c-16-20-26-33-26-46a26 26 0 0 1 52 0c0 13-10 26-26 46z" fill="#17233F"/><rect x="414" y="283" width="12" height="26" rx="6" fill="#F5F3EE"/><path d="M414 290l12-4M414 297l12-4M414 304l12-4" stroke="#C42032" stroke-width="2"/></g>
      <g transform="translate(300 206)"><rect width="230" height="58" rx="14" fill="#F5F3EE" stroke="rgba(23,35,63,.2)"/><text x="16" y="29" font-family="Big Shoulders Display, Arial Narrow, sans-serif" font-weight="700" font-size="24" fill="#17233F">Barbershop Ferry</text><text x="16" y="47" font-family="Spline Sans Mono, monospace" font-size="10.5" letter-spacing="1.5" fill="#4E5A72">STATIONSSTRAAT 130</text></g>
      <g transform="translate(730 60)" fill="none" stroke="#4E5A72" stroke-width="1.5"><circle r="20"/><path d="M0 -14 5 4 0 0 -5 4z" fill="#4E5A72"/></g>
    </svg>'''
    return head('Contact &amp; route — Barbershop Ferry, Stationsstraat 130 Waalwijk', 'Barbershop Ferry, Stationsstraat 130, 5141 GH Waalwijk. Bel 06 28 71 89 27 of plan je afspraak online.', 'assets/img/k7.webp') + header('contact.html') + f'''<section class="phero" style="--to:var(--foam)" aria-label="Contact">
  <div class="bg"><div class="kbw" data-kb><picture><source media="(max-width:760px)" srcset="assets/img/k7-m.webp"><img src="assets/img/loop-contact-0.webp" alt="Een lege kersenrode barbiersstoel in een ruimte met mintgroene tegels en daglicht" fetchpriority="high"></picture><video data-auto data-src="assets/loop-contact.mp4" poster="assets/img/loop-contact-0.webp" muted playsinline loop preload="none" aria-hidden="true" class="dv"></video></div></div>
  <canvas class="dust" data-k="warm" aria-hidden="true"></canvas>
  <span class="cap mono">Sfeerbeeld</span>
  <div class="wrap"><div class="box" style="margin-left:auto">
    <span class="chip">{ADR} · Waalwijk</span>
    <h1 class="words" style="margin-top:16px">kom even langs.</h1>
    <p class="lead rv">Plan je afspraak online of bel even. Je vindt Barbershop Ferry aan de Stationsstraat in Waalwijk.</p>
    <div class="row rv">{B_BOEK()}{B_TEL()}</div>
  </div></div>
</section>

<section class="bg-foam" style="padding-top:clamp(40px,8vh,80px)">
  <div class="wrap">
    <div class="cards">
      <div class="gcard glow-follow rv"><span class="eyebrow">Adres</span><b>{ADR}, {PC}</b>{B_ROUTE('sm')}</div>
      <div class="gcard glow-follow rv" style="--d:1"><span class="eyebrow">Telefoon</span><b>{TELT}</b>{btn(TEL, 'Bel nu', 'sm', 'tel')}</div>
      <div class="gcard glow-follow rv" style="--d:2"><span class="eyebrow">WhatsApp</span><b>Appen kan misschien ook</b><span class="wa-wrap">{btn(WA, 'WhatsApp', 'ghost sm', 'wa', True)}<span class="wa-note">nog te bevestigen</span></span></div>
      <div class="gcard glow-follow rv"><span class="eyebrow">Online afspraak</span><b>Plan hier in een minuut</b>{btn(BOEK, 'Afspraak maken', 'sm', 'cal')}</div>
      <div class="gcard glow-follow rv wide" id="tijden" style="--d:1"><span class="eyebrow">Wanneer?</span><b>Kies online een dag en tijd, of bel even</b></div>
    </div>
  </div>
</section>

<section class="bg-foam" style="padding-top:clamp(56px,10vh,96px);padding-bottom:clamp(40px,7vh,72px)">
  <div class="wrap two" style="align-items:center">
    <div>
      <h2 class="words">je vindt ons aan de Stationsstraat.</h2>
      <p class="lead rv" style="margin-top:16px">{ADR}, {PC} (Noord-Brabant).</p>
      <div class="row rv">{btn(ROUTE, 'Open in Google Maps', '', 'pin', True)}</div>
    </div>
    <figure class="map rv" style="--d:1">{mapsvg}<figcaption class="mono">Ferry · schematisch</figcaption></figure>
  </div>
</section>

<section class="bg-marble seam-top" style="--from:var(--foam);padding-bottom:clamp(24px,4vh,48px)">
  <div class="wrap two">
    <div><span class="eyebrow">Kort &amp; handig</span><h2 class="words">goed om te weten.</h2></div>
    <div class="rv">{faqh}</div>
  </div>
</section>
''' + finale('var(--marble)', ('assets/img/b1.webp', 'assets/img/b1-m.webp', 'Sfeerbeeld', 'tight')) + footer()

# ======================================================================= 404
def p404():
    return head('Pagina niet gevonden — Barbershop Ferry', 'Deze pagina is weggedraaid. Ga terug naar het begin of plan je afspraak bij Barbershop Ferry.', 'assets/img/k2.webp') + header('') + f'''<section class="p404">
  <picture><source media="(max-width:760px)" srcset="assets/img/k2-m.webp"><img class="pimg" src="assets/img/k2.webp" alt="Close-up van een rood-wit-blauwe barberpaal"></picture>
  <canvas class="glints" aria-hidden="true"></canvas>
  <span class="cap mono">Sfeerbeeld</span>
  <div class="wrap"><div class="box glow-follow">
    <span class="eyebrow">404</span>
    <h1 class="words">deze pagina is weggedraaid.</h1>
    <p class="lead rv" style="margin-top:16px">Hier staat niets (meer). Ga terug naar het begin, of plan meteen je afspraak.</p>
    <div class="row rv">{btn('index.html', 'Naar home', 'ghost')}{B_BOEK()}</div>
  </div></div>
</section>
''' + footer()

def copy_md():
    L = ['# COPY — Barbershop Ferry (NL)', 'Rol: copywriter. Gegenereerd uit `_notes/build.py` (bron van waarheid). Alleen feiten uit BRIEF; geen prijzen, tijden, reviews of namen.', '',
         '## Home — hero', '**strak geknipt aan de Stationsstraat.**', HERO_LEAD, '', '## Home — hoofdstukken over de film (regel · onderschrift · kaart)']
    for c, (h, p, _) in zip(CH, CARDS):
        L += [f'- **{html.unescape(c["t"]).replace("<em>","").replace("</em>","")}** — {c["s"]}', f'  - *{h}*: {p}']
    L += ['', '## Diensten (Fresha)'] + [f'- **{html.unescape(n)}** ({html.unescape(en)}) — {t} · prijs op aanvraag' for i, n, en, t in SVC]
    for i, h, c, ps in SVCX: L += ['', f'### {html.unescape(h)}'] + ps
    L += ['', '## Afspraak', 'plan je stoel. — 4 stappen: dienst → dag & tijd → gegevens → bevestigd. Demo: niets geboekt.', '', '## Over ons', 'een barbier om de hoek. / meer dan een knipbeurt. / dit verhaal vertelt Ferry zelf (placeholder-vragen).', '', '## Contact', f'{ADR}, {PC} · {TELT} · WhatsApp (nog te bevestigen) · {HOURS_NOTE}']
    (OUT / 'COPY.md').write_text('\n'.join(L) + '\n', encoding='utf-8')

pages = {'index.html': index().replace('{SEG}', SEGS['d']).replace('{SEGM}', SEGS['m']), 'diensten.html': diensten(), 'afspraak.html': afspraak(), 'over-ons.html': over(), 'contact.html': contact(), '404.html': p404()}
for n, s in pages.items():
    (OUT / n).write_text(s, encoding='utf-8')
    print(n, len(s))
copy_md()
