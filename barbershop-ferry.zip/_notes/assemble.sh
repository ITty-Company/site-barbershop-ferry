#!/bin/bash
# usage: assemble.sh <clipdir> <sitedir>
# main film (seg.py output, crf16 master) -> all-intra (-g 1) H.264 chunks, each <= ~1.9 MB (check_site limit 2.1 MB),
# chunk list + start times -> _notes/segs.json (read by build.py). Also over-ons film, loops, posters, keyframe webps.
set -e
C=$1; S=$2; O=$S/assets; mkdir -p $O/img
python3 - "$C" "$S" <<'PY'
import subprocess, json, sys, os
C, S = sys.argv[1], sys.argv[2]; O = S + '/assets'
LIM = 1.85e6
def enc(src, out, crf, ss=None, n=None, extra=[]):
    cmd = ['ffmpeg', '-y', '-v', 'error']
    cmd += ['-i', src]
    vf = 'format=yuv420p'
    if ss is not None: vf = f'trim=start_frame={ss}:end_frame={ss+n},setpts=PTS-STARTPTS,' + vf
    cmd += ['-vf', vf, '-c:v', 'libx264', '-preset', 'slow', '-crf', str(crf), '-g', '1', '-pix_fmt', 'yuv420p', '-movflags', '+faststart', '-an'] + extra + [out]
    subprocess.run(cmd, check=True)
def sizes(f):
    o = subprocess.run(['ffprobe', '-v', 'error', '-select_streams', 'v', '-show_entries', 'packet=size', '-of', 'csv=p=0', f], capture_output=True, text=True).stdout.split()
    return [int(x) for x in o]
res = {}
for key, src, crf, pre in (('d', C + '/main.mp4', 30, 'film-main'), ('m', C + '/main-m.mp4', 29, 'film-main-m')):
    enc(src, '/tmp/full.mp4', crf)
    sz = sizes('/tmp/full.mp4'); N = len(sz)
    cuts = [0]; acc = 0
    for i, b in enumerate(sz):
        if acc + b > LIM: cuts.append(i); acc = 0
        acc += b
    cuts.append(N)
    for f in os.listdir(O):
        if f.startswith(pre + '-') and f.endswith('.mp4') and f[len(pre)+1:-4].isdigit(): os.remove(O + '/' + f)
    srcs = []
    for k in range(len(cuts) - 1):
        a = cuts[k]; b = min(cuts[k + 1] + 1, N)   # 1 frame overlap so every chunk ends on the next chunk's first frame
        out = f'{O}/{pre}-{k+1}.mp4'; enc(src, out, crf, a, b - a); srcs.append(f'assets/{pre}-{k+1}.mp4')
        print(out, os.path.getsize(out))
    res[key] = ','.join(f'{c/24:.4f}' for c in cuts[:-1]); res['src' if key == 'd' else 'srcm'] = '|'.join(srcs)
# chapter rest times: 70% into every hold that carries a chapter (b1/b2 are passing shots)
lg = open(C + '/log-desktop.txt').read().strip().splitlines()[-1]
rests, total = json.loads(lg)
res['at'] = [round(a + .7 * (b - a), 2) for k, a, b in rests if k not in ('b1', 'b2')]
res['dur'] = round(total, 2)
json.dump(res, open(S + '/_notes/segs.json', 'w'), indent=1)
print(res)
PY
F=/tmp/asm; mkdir -p $F
ffmpeg -y -v error -i $C/main.mp4 -frames:v 1 $F/p0.png
ffmpeg -y -v error -sseof -0.05 -i $C/main.mp4 -frames:v 1 $F/p1.png
ffmpeg -y -v error -i $C/main-m.mp4 -frames:v 1 $F/p2.png
ffmpeg -y -v error -sseof -0.05 -i $C/main-m.mp4 -frames:v 1 $F/p3.png
ffmpeg -y -v error -i $C/over.mp4 -vf format=yuv420p -c:v libx264 -crf 29 -g 1 -movflags +faststart -an $O/film-over.mp4
ffmpeg -y -v error -i $C/over-m.mp4 -vf format=yuv420p -c:v libx264 -crf 28 -g 1 -movflags +faststart -an $O/film-over-m.mp4
ffmpeg -y -v error -i $O/film-over.mp4 -frames:v 1 $F/p4.png
ffmpeg -y -v error -i $O/film-over-m.mp4 -frames:v 1 $F/p5.png
for L in loop-afspraak loop-contact; do
  ffmpeg -y -v error -i $C/$L.mp4 -filter_complex "[0:v]split[a][b];[b]reverse[r];[a][r]concat=n=2:v=1,format=yuv420p" -c:v libx264 -crf 28 -movflags +faststart -an $O/$L.mp4
  ffmpeg -y -v error -i $O/$L.mp4 -frames:v 1 $F/$L.png
done
python3 - "$F" "$O/img" <<'PY'
import sys; from PIL import Image
F, D = sys.argv[1], sys.argv[2]
for a, b, q in (('p0', 'film-main-0', 82), ('p1', 'film-main-end', 84), ('p2', 'film-main-m-0', 80), ('p3', 'film-main-m-end', 82), ('p4', 'film-over-0', 82), ('p5', 'film-over-m-0', 80), ('loop-afspraak', 'loop-afspraak-0', 82), ('loop-contact', 'loop-contact-0', 82)):
    Image.open(f'{F}/{a}.png').convert('RGB').save(f'{D}/{b}.webp', quality=q)
PY
# keyframe stills: desktop 1344x752 webp + mobile 9:16-ish crops (600x960) centred on the subject (same cx as seg.py)
python3 - "$S" <<'PY'
import sys, os; from PIL import Image
S = sys.argv[1]; K = os.environ.get('KF', '/home/claude/bf/kf/raw/')
CX = {'k1': .3, 'k2': .46, 'k3': .22, 'k4': .44, 'k5': .5, 'k6': .26, 'k7': .5, 'k8': .3, 'a1': .74, 'd1': .3, 'b1': .4, 'b2': .55}
for k, cx in CX.items():
    im = Image.open(K + k + '.png').convert('RGB')
    im.save(f'{S}/assets/img/{k}.webp', quality=80, method=6)
    W, H = im.size; cw = int(H * 600 / 960); x = int(min(max(cx * W - cw / 2, 0), W - cw))
    im.crop((x, 0, x + cw, H)).resize((600, 960), Image.LANCZOS).save(f'{S}/assets/img/{k}-m.webp', quality=78, method=6)
PY
ls -la $O $O/img
