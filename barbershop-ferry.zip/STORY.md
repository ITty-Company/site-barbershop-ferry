# STORY — Barbershop Ferry · SHOT LIST (Mode B: overgangen in code)
Rol: story-architect. Master: references/SCROLL_FILM_PROMPT.md (licht & gevarieerd, §0a). Mechaniek: sites/kapsalon-haar (video-scrub, -g 1).

## Idee in één zin
**Een gewone ochtend aan de Stationsstraat: de barberpaal draait, en de camera duikt erin — door de rood-wit-blauwe banen naar het werkblad waar de opzetkammen klaarliggen van klein naar groot (de fade), langs het mes in het zonlicht, de dampende handdoek en een druppel baardolie, tot de lege rode stoel: jouw beurt.**

Hoofdobject: **de barberpaal / het ritme van de banen** — hij opent het verhaal (K1, K2), wordt de overgang (diagonale paal-banen schuiven over het beeld = K2→K3), keert terug als voortgangsbalk (draaiende paal-strook rechts), als pagina-overgang (paal-banen met logo) en in de finale (K8: de paal brandt in de schemering). De tondeuse + opzetkammen zijn het «tweede object»: de fade van #0 tot #8 als visuele gradient.

Geen mensen, geen handen: gereedschap ligt; dingen gebeuren vanzelf (stof zweeft, damp stijgt, druppel valt).

## Keyframes (Higgsfield gpt_image_2_6, 16:9, 1344×752) — 13 beelden totaal, 0 afgekeurd
Ronde 1: K1–K8, D1, A1. Ronde 2 (critic): **K8 opnieuw met K1 als referentie** (zelfde gevel, blauw uur, rode stoel), **B1** (zelfde mint ruimte: werkblad met tondeuse + opzetkammen, rode stoel in de voorgrond, ref K7), **B2** (zelfde ruimte: oliedruppel/schaal op de voorgrond, rode stoel op de achtergrond, ref K7 + K5). K1: blauwe stoel achter het raam lokaal naar kersenrood gekleurd (continuïteit met K7/K8).
| # | beeld | rol |
|---|---|---|
| K1 | gevel ochtend, paal, rode stoel achter raam | hero / hfst 1 |
| K2 | macro paal | hfst 2 |
| K7 | mint tegelruimte, rode stoel | hfst 3 + hfst 8 (zelfde plek, begin en eind van binnen) |
| B1 | werkblad tegen de tegels, stoel-rand voorgrond | doorgangsshot |
| K3 | opzetkammen van klein naar groot (top-down) | hfst 4 |
| K4 | tondeusemes in zonnestraal | hfst 5 |
| K6 | dampende handdoek | hfst 6 |
| K5 | druppel baardolie | hfst 7 |
| B2 | zelfde schaal, ruimte + stoel erachter | doorgangsshot |
| K8 | zelfde gevel, blauw uur | portaal (gevel max 2× op de site: K1 film, K8 portaal) |
| D1, A1 | flat-lay rij / bankje | diensten-pan, afspraak, over-ons |

## Hoofdfilm (index) — 28 s, ÉÉN doorlopende camera (Mode B, `_notes/seg.py`), 24 fps all-intra, desktop 1280×720 + mobiel 480×768, in delen ≤ 1.9 MB
Techniek: dieptekaart per keyframe (`_notes/depth.py`, Depth-Anything-V2-Small) → 2.5D-parallax (dichtbij groeit/schuift meer dan ver weg) bij elke dolly/truck; de camera staat nooit stil (holds = langzame drift, overgangen nemen die snelheid over, C1-continu, en versnellen naar een match-punt); echte motion blur (gemiddelde van camerastanden). Geen wipes, geen rimpel.
| overgang | match-cut |
|---|---|
| K1 → K2 | dolly de paal in → macro van dezelfde paal |
| K2 → K7 | rode baan van de paal → rood leer van de stoel (stoel komt uit het rood naar voren) |
| K7 → B1 | camera schuift naar rechts langs de tegels naar het werkblad |
| B1 → K3 | kantelen naar beneden op de rij opzetkammen → dezelfde rij van boven |
| K3 → K4 | blauwe tondeuse → zijn mes |
| K4 → K6 | omhoog de zonnestraal in (licht bloeit op) → het raam naast de handdoek |
| K6 → K5 | de damp in (witte nevel) → mint nevel boven de olie |
| K5 → B2 | dezelfde schaal op dezelfde plek; de ruimte en de stoel verschijnen erachter |
| B2 → K7 | scherpstellen op de stoel → de stoel |
Hoofdstukken staan op de rustpunten (70% in elke hold, `segs.json` → `at`), titel+onderschrift+kaart ≥ 60% van elk hoofdstuk volledig zichtbaar. Inktblauwe titels op een kalk-scrim (alle frames zijn licht).
→ portaal: lichtgordijn (warm wit) → K8 «tot zo aan de Stationsstraat.»

## Binnenpagina's
- **diensten** — pan-film over D1 (5 haltes: knippen · tondeuse · trimmer · olie · mes) + 4 echte Fresha-diensten, «prijs op aanvraag».
- **afspraak** — hero A1 (code-loop: langzame push), 4 stappen dienst → dag/tijd → gegevens → bevestiging, demo, .ics.
- **over-ons** — film B1 (werkblad) → lichtovergang → A1 (bankje), eerlijke tekst, «dit verhaal vertelt Ferry zelf».
- **contact** — hero K7-loop (stoel), adres, bellen, WhatsApp (nog te bevestigen), schematische kaart Stationsstraat, Google Maps-link.
- **404** — K2 «deze pagina is weggedraaid.»
Pagina-overgang: «paal» — diagonale rood/wit/blauwe banen met het woord van de bestemming.
