# TYPE — Barbershop Ferry
Rol: type-director. Paar «uithangbord + leesletter + HUD».
- **Display: Big Shoulders Display 700** — smalle, hoge letter in de geest van oude winkelbelettering en stationsborden (Stationsstraat). Kleine letters, strak (line-height .9, letter-spacing -.005em). Hoofdstukregels 3–8rem.
- **Tekst: Atkinson Hyperlegible Next 400/500** — zeer goed leesbaar op telefoon, diakrieten ok. body 17–19px, lh 1.6.
- **HUD/mono: Spline Sans Mono 500** — capitals, tracking .16em, tabular-nums.
- Google Fonts: `family=Big+Shoulders+Display:wght@600;700&family=Atkinson+Hyperlegible+Next:wght@400;500&family=Spline+Sans+Mono:wght@500` (getest, HTTP 200).
- Journal-check: geen van de drie eerder gebruikt.
