# BRIEF — Barbershop Ferry (Waalwijk)
Rol: lead-scout (gegeven door orchestrator) · 19.11.2026 · slug `barbershop-ferry`

## Geverifieerde feiten (ALLEEN deze)
- Naam: **Barbershop Ferry** (op Fresha: «Barbershop Ferry💈»)
- Adres: **Stationsstraat 130, 5141 GH Waalwijk** (postcode volgens Fresha-vermelding)
- Telefoon: **+31 6 28718927** (06 28 71 89 27). WhatsApp waarschijnlijk hetzelfde nummer → wa.me-link met label «nog te bevestigen».
- Diensten op Fresha: **Haircut, Haircut & Beard Trim, Beard Trim, Beard Shave.** Geen prijzen bekend.
- Openingstijden: **onbekend** → «bel of boek online».
- Geen eigen website, geen socials gevonden. Wel boekbaar via Fresha.
- Taal site: Nederlands.

## Niet verzinnen
Geen prijzen (alleen «prijs op aanvraag» / «zie Fresha»), geen openingstijden, geen reviews/sterren, geen oprichtingsjaar, geen namen van barbers, geen awards, geen merken, geen «walk-ins welkom». «Ferry» is de naam van de zaak — we doen niet alsof we weten wie Ferry is.

## Waarom deze klant
Een barbershop met alleen een Fresha-vermelding: wie «barbier Waalwijk» googelt vindt geen eigen site, geen foto's, geen verhaal. Een eigen site met online afspraak (later gekoppeld aan Fresha), route en een duidelijk belknopje lost dat op.

## Wat te zeggen tegen de klant (voor orchestrator)
«Je staat op Fresha, maar wie je zoekt vindt geen eigen site. We hebben een voorbeeldsite gemaakt: een korte ‹film› van je zaak bij het scrollen, je vier diensten, online afspraak in 4 stappen, route naar de Stationsstraat. Echte foto's, tijden en prijzen vullen we samen in.»

## Verschil met eerdere barbers in Waalwijk (golden-fingers, kapsalon-haar)
golden-fingers = marmer, bordeaux & bladgoud, scheermes/stoel, ochtend → gouden uur. kapsalon-haar = petrol & koper, kleur-lok.
**Ferry = mint tegels, terrazzo, kersenrood van de barberpaal, inktblauw; het verhaal van de tondeuse en de opzetkammen («de fade») — buiten → paal → werkblad → mes → handdoek → olie → stoel.** Condensed uithangbord-letter i.p.v. serif.
